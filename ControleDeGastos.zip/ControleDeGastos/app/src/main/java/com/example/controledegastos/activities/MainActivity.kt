package com.example.controledegastos.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.controledegastos.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnAddExpense = findViewById<Button>(R.id.btnAddExpense)
        val btnListExpense = findViewById<Button>(R.id.btnListExpense)
        // Se houver um TextView txtSummary no layout, você pode fazer:
        // val txtSummary = findViewById<TextView>(R.id.txtSummary)

        btnAddExpense.setOnClickListener {
            val intent = Intent(this, AddExpenseActivity::class.java)
            startActivity(intent)
        }

        btnListExpense.setOnClickListener {
            val intent = Intent(this, ListExpenseActivity::class.java)
            startActivity(intent)
        }

        // Exemplo (opcional) de atribuir texto a um TextView:
        // txtSummary.text = "Bem-vindo(a) ao Controle de Gastos!"
    }
}
